#!/bin/sh

/usr/bin/profiles -R -p 9f9a0b1f-7b17-4656-92aa-b7046ad88d00
/bin/rm -f /usr/local/share/DisableTimeMachineDiskOffer.mobileconfig
/usr/sbin/pkgutil --forget com.github.makeprofilepkg.DisableTimeMachineDiskOffer
