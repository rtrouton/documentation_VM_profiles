#!/bin/sh

/usr/bin/profiles -R -p ef1d9164-ff31-444f-82f2-d145813b542e
/bin/rm -f /usr/local/share/DisplayLoginwindowInfo.mobileconfig
/usr/sbin/pkgutil --forget com.github.makeprofilepkg.DisplayLoginwindowInfo
