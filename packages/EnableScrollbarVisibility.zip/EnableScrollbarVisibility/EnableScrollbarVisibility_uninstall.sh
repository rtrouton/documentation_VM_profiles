#!/bin/sh

/usr/bin/profiles -R -p 1b756ac7-510b-4c08-8f1f-96dc68ac4501
/bin/rm -f /usr/local/share/EnableScrollbarVisibility.mobileconfig
/usr/sbin/pkgutil --forget com.github.makeprofilepkg.EnableScrollbarVisibility
