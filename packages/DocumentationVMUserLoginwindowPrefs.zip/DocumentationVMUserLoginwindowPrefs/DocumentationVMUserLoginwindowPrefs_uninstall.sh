#!/bin/sh

/usr/bin/profiles -R -p DocumentationVMUserLoginwindowPrefs
/bin/rm -f /usr/local/share/DocumentationVMUserLoginwindowPrefs.mobileconfig
/usr/sbin/pkgutil --forget com.github.makeprofilepkg.DocumentationVMUserLoginwindowPrefs
