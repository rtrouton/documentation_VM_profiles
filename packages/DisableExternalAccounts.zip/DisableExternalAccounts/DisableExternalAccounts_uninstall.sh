#!/bin/sh

/usr/bin/profiles -R -p 0d630132-8506-43c6-8265-82623efa2648
/bin/rm -f /usr/local/share/DisableExternalAccounts.mobileconfig
/usr/sbin/pkgutil --forget com.github.makeprofilepkg.DisableExternalAccounts
