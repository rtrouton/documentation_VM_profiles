#!/bin/bash

# The version of the package
PKG_VERSION="2017.06.08"

# The identifier of the package
PKG_ID="com.github.makeprofilepkg.DisableExternalAccounts"

# The identifier of the profile
PROFILE_ID="0d630132-8506-43c6-8265-82623efa2648"

# The version installed from pkgutil
VERSION_INSTALLED=`/usr/sbin/pkgutil --pkg-info "$PKG_ID" | grep version | sed 's/^[^:]*: //'`

if ( /usr/bin/profiles -P | /usr/bin/grep -q $PROFILE_ID ); then
    # Profile is present, check the version
    if [ "$VERSION_INSTALLED" = "$PKG_VERSION" ]; then
        # Correct version, all good
        exit 1
    else
        exit 0
    fi
else
    # Profile isn't there, need to install
    exit 0
fi
