#!/bin/sh

/usr/bin/profiles -R -p DisableGatekeeperAutomaticReenablement
/bin/rm -f /usr/local/share/DisableGatekeeperAutomaticReenablement.mobileconfig
/usr/sbin/pkgutil --forget com.github.makeprofilepkg.DisableGatekeeperAutomaticReenablement
