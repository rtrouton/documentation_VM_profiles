#!/bin/sh

/usr/bin/profiles -R -p DocumentationVMFinderPrefs
/bin/rm -f /usr/local/share/DocumentationVMFinderPrefs.mobileconfig
/usr/sbin/pkgutil --forget com.github.makeprofilepkg.DocumentationVMFinderPrefs
