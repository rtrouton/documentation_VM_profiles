#!/bin/sh

/usr/bin/profiles -R -p DocumentationVMSidebarPrefs
/bin/rm -f /usr/local/share/DocumentationVMSidebarPrefs.mobileconfig
/usr/sbin/pkgutil --forget com.github.makeprofilepkg.DocumentationVMSidebarPrefs
